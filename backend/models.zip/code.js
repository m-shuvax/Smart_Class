const User = require("./models/userModel");

console.log(User.find);